INSERT INTO `promo_codes` VALUES   ('1','2018-10-30 16:03:14','1st_test','just the first test','BCH','0000000000.0020000000');
INSERT INTO `promo_codes` VALUES ('2','2018-10-30 20:09:24','$5.00 Worth Of BCH','2nd_test','BCH','0000000000.0250000000');
INSERT INTO `promo_codes` VALUES ('3','2018-10-30 20:10:56','$15.00 Worth Of DEMO','3rd_test','BCH','0000000000.0330000000');
